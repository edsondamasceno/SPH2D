#ifndef NEIGHBORDATA_HH
#define NEIGHBORDATA_HH

struct NeighborData {
  int idx;
  
  Vector d_normalized;
  float d;
  float d_squared;
};

#endif

